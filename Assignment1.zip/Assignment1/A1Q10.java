public class A1Q10
 {
    public static void main (String args[])
	{
	double a=4.0D,b=1D,c=3D,d=5D,e=7D,f=9D,g=11D;
	double x=a * (b - (b/c) + (b/d) - (b/e) + (b/f) - (b/g));
	
	System.out.println(x);
	}}