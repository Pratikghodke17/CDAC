import java.util.*;
class A1Q12
{ public static void main (String args[])
{ 
   Scanner sc= new Scanner (System.in);
   System.out.println("Input three digits:");
    int i = sc.nextInt();
    int j = sc.nextInt();
    int k = sc.nextInt();
	int x = (i+j+k)/2;
	
	System.out.println("average:"+x);
	}}