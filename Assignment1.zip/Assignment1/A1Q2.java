public class A1Q2
{
public static void main(String args[])
{
int num1=74;
int num2=36;
int num3=num1+num2;
System.out.println("Sum:"+num3);
}
}