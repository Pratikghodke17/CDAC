public class A1Q3
{
public static void main(String args[])
{
int num1=50;
int num2=3;
int num3=num1/num2;
System.out.println("Sum:"+num3);
}
}