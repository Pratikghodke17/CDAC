import java.util.Scanner;
public class A1Q5
{
public static void main(String args[]) 
{
Scanner sc = new Scanner (System.in);

	System.out.println ("Input first number");
	System.out.println ("Input second number");
	
	int i=sc.nextInt();
    int j=sc.nextInt();
	int k=i*j;
	
	
	System.out.println ("Output:"+k);
 }
}