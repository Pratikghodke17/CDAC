import java.util.*;
class A1Q7
{
public static void main(String args[])

{ 
   Scanner sc = new Scanner (System.in);
   System.out.println("Input no:");
   
   int i = sc.nextInt();
   for(int j=1; j<=10; j++)
   { 
    int y=i*j;
	System.out.println(i+"X"+j+"="+y);
	}
	}
	}