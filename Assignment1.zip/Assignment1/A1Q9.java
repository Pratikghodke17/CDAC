public class A1Q9
 {
    public static void main (String args[])
	{
	double a=25.5D,b=3.5D,c=40.5D,d=4.5D;
	double x=((a * b - b* b) / (c - d));
	System.out.println(x);
	}}